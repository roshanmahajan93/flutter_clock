import 'dart:math';

import 'package:flutter/material.dart';

class common_shadow extends BoxDecoration {



  @override
  Widget build(BuildContext context) {
    return Container(
        color: Color(0xFFA3B1C6),

    );
  }
}