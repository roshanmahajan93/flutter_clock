// Copyright 2019 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_clock_helper/model.dart';
import 'package:intl/intl.dart';
import 'package:vector_math/vector_math_64.dart' show radians;

import 'Clock_Painter.dart';
import 'MyCustomContainer.dart';
import 'container_hand.dart';
import 'drawn_hand.dart';

/// Total distance traveled by a second or a minute hand, each second or minute,
/// respectively.
final radiansPerTick = radians(360 / 60);

/// Total distance traveled by an hour hand, each hour, in radians.
final radiansPerHour = radians(360 / 12);

/// A basic analog clock.
///
/// You can do better than this!
class AnalogClock extends StatefulWidget {
  const AnalogClock(this.model);

  final ClockModel model;

  @override
  _AnalogClockState createState() => _AnalogClockState();
}

class _AnalogClockState extends State<AnalogClock> {
  var _now = DateTime.now();
  var _temperature = '';
  var _temperatureRange = '';
  var _condition = '';
  var _location = '';
  Timer _timer;

  @override
  void initState() {
    super.initState();
    widget.model.addListener(_updateModel);
    // Set the initial values.
    _updateTime();
    _updateModel();
  }

  @override
  void didUpdateWidget(AnalogClock oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.model != oldWidget.model) {
      oldWidget.model.removeListener(_updateModel);
      widget.model.addListener(_updateModel);
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    widget.model.removeListener(_updateModel);
    super.dispose();
  }

  void _updateModel() {
    setState(() {
      _temperature = widget.model.temperatureString;
      _temperatureRange = '(${widget.model.low} - ${widget.model.highString})';
      _condition = widget.model.weatherString;
      _location = widget.model.location;
    });
  }

  void _updateTime() {
    setState(() {
      _now = DateTime.now();
      // Update once per second. Make sure to do it at the beginning of each
      // new second, so that the clock is accurate.
      _timer = Timer(
        Duration(seconds: 1) - Duration(milliseconds: _now.millisecond),
        _updateTime,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    // There are many ways to apply themes to your clock. Some are:
    //  - Inherit the parent Theme (see ClockCustomizer in the
    //    flutter_clock_helper package).
    //  - Override the Theme.of(context).colorScheme.
    //  - Create your own [ThemeData], demonstrated in [AnalogClock].
    //  - Create a map of [Color]s to custom keys, demonstrated in
    //    [DigitalClock].
    final customTheme = Theme.of(context).brightness == Brightness.light
        ? Theme.of(context).copyWith(
            // Minute hand.
            backgroundColor: Color(0xFFE0E5EC),
          )
        : Theme.of(context).copyWith(
            backgroundColor: Color(0xFF3C4043),
          );



    return Container(
      color: customTheme.backgroundColor,
      child: Container(
        padding: const EdgeInsets.all(15),
        margin: const EdgeInsets.all(15),
        constraints: BoxConstraints.tightForFinite(),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: Color(0xFFE0E5EC),
          // the box shawdow property allows for fine tuning as aposed to shadowColor
          boxShadow: [
            new BoxShadow(
                color: Color(0xFFA3B1C6),
                // offset, the X,Y coordinates to offset the shadow
                offset: new Offset(10.0, 5.0),
                // blurRadius, the higher the number the more smeared look
                blurRadius: 18.0,
                spreadRadius: 1.0),
            new BoxShadow(
                color: Color(0xFFFFFFFF),
                // offset, the X,Y coordinates to offset the shadow
                offset: new Offset(-10.0, -5.0),
                // blurRadius, the higher the number the more smeared look
                blurRadius: 18.0,
                spreadRadius: 1.0)
          ],
        ),
        child: Stack(
          children: [
            // Example of a hand drawn with [CustomPainter].
            Center(
              child: Container(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height,
                padding: const EdgeInsets.all(2.0),
                child: new CustomPaint(
                  painter: new Clock_Painter(),
                ),
              ),
            ),
            ContainerHand(
              color: Colors.transparent,
              size: 0.5,
              angleRadians: _now.hour * radiansPerHour +
                  (_now.minute / 60) * radiansPerHour,
              child: Transform.translate(
                offset: Offset(0.0, -81.0),
                child: Container(
                  child: MyCustomContainer(
                    progress: 1.0,
                    size: 100,
                    backgroundColor: Colors.white,
                    progressColor: Colors.grey[700],
                  ),
                  width: 30,
                  height: 170,
                ),
              ),
            ),

            DrawnHand(
              color: Colors.grey[700],
              thickness: 14,
              size: 0.9,
              angleRadians: _now.minute * radiansPerTick,

            ),

            Center(
              child: Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: customTheme.backgroundColor,
                  boxShadow: [
                    new BoxShadow(
                        color: Color(0xFFA3B1C6),
                        // offset, the X,Y coordinates to offset the shadow
                        offset: new Offset(10.0, 5.0),
                        // blurRadius, the higher the number the more smeared look
                        blurRadius: 18.0,
                        spreadRadius: 1.0),
                    new BoxShadow(
                        color: Color(0xFFFFFFFF),
                        // offset, the X,Y coordinates to offset the shadow
                        offset: new Offset(-10.0, -5.0),
                        // blurRadius, the higher the number the more smeared look
                        blurRadius: 18.0,
                        spreadRadius: 1.0)
                  ],
                ),
              ),
            ),

            // Example of a hand drawn with [Container].
            DrawnHand(
              color: Color(0xFFFF8A5C),
              thickness: 4,
              size: 1,
              angleRadians: _now.second * radiansPerTick,
            ),

            Center(
              child: Container(
                width: 12,
                height: 12,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white,
                ),
              ),
            ),
            Center(
              child: Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.grey[700],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
